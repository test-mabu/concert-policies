package concert.workflows.run.policy_allow_all

import rego.v1

deny contains reason if {
	false
	reason := ""
}

review contains reason if {
	false
	reason := ""
}
